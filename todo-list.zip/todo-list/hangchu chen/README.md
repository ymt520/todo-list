[前端创意中心](https://github.com/chuntonggao/creativity-center)试听课的 Todo List Project 代码

初始代码在`master` branch 上。  
   
Vanilla JS Solution 在 `vanilla-js-solution` branch 上。   
   
TypeScript Solution 在 `typescript-solution` branch 上。   

  
请按照下图说明，下载 recommended extensions
![下载 recommended extensions](./asset/how-to-download-extensions.jpg)   
